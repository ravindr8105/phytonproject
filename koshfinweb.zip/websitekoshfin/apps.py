from django.apps import AppConfig


class WebsitekoshfinConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'websitekoshfin'
