from django.contrib import admin
from websitekoshfin.models import person

# Register your models here.
admin.site.register(person)